

// registro.js
const PRICES = { standard: 13000, premium: 20000 };

const CANDIDATE_BASES = [
  'http://127.0.0.1:3000','http://localhost:3000',
  'http://127.0.0.1:3001','http://localhost:3001'
];
let API_BASE=null;
async function findApiBase(){
  if(API_BASE) return API_BASE;
  for(const b of CANDIDATE_BASES){
    try{ const r=await fetch(b+'/health'); if(r.ok){ API_BASE=b; return b; } }catch{}
  }
  throw new Error('API no disponible');
}

// DOM
const $form = document.getElementById('form-registro');
const $feedback = document.getElementById('feedback');

const $autosContainer = document.getElementById('autos-container');
const $tpl = document.getElementById('tpl-auto');
const $btnAddAuto = document.getElementById('btn-add-auto');

// Pago simulado (al final del form)
const $pagoSim = document.getElementById('pago-sim');
const $btnProcesar = document.getElementById('btn-procesar');
const $pagoFlow = document.getElementById('pago-flow');
const $brandGroup = document.getElementById('brand-group');
const $btnPagar = document.getElementById('btn-pagar');
const $pagoEstado = document.getElementById('pago-estado');
const $cardLast4 = document.getElementById('card-last4');
const $cardExp = document.getElementById('card-exp');

let paymentOk = false;
let selectedBrand = null;

// Estado por-select
const modelosState = new WeakMap();

// --- init ---
init();
async function init(){ addAutoRow(true); initPlanBox(); }

function showFeedback(msg, ok=true){
  if(!$feedback) return;
  $feedback.hidden = false;
  $feedback.className = 'flash ' + (ok ? 'flash-success' : 'flash-error');
  $feedback.textContent = (ok?'✔️ ':'❌ ') + msg;
}
function hideFeedback(){ if($feedback){ $feedback.hidden=true; $feedback.textContent=''; $feedback.className='flash'; } }

// --- Autos ---
$btnAddAuto.addEventListener('click', ()=> addAutoRow());
$autosContainer.addEventListener('click', (e)=>{
  if(e.target.classList.contains('btn-remove-auto')){
    e.target.closest('.auto-row')?.remove();
    if (!$autosContainer.querySelector('.auto-row')) addAutoRow(true);
  }
});
$autosContainer.addEventListener('change', onAutosChange);

function addAutoRow(loadMarcas=false){
  const node = document.importNode($tpl.content, true);
  $autosContainer.appendChild(node);
  const $row = $autosContainer.querySelector('.auto-row:last-child');
  const $marca = $row.querySelector('.auto-marca');
  const $modelo = $row.querySelector('.auto-modelo');
  modelosState.set($modelo, { loading:false, marca:'' });
  if(loadMarcas) fillMarcas($marca);
  else {
    const firstMarca = document.querySelector('.auto-marca');
    if(firstMarca && firstMarca.options.length>1) copyOptions(firstMarca, $marca);
    else fillMarcas($marca);
  }
}

function copyOptions(fromSelect,toSelect){
  toSelect.innerHTML='';
  for(const opt of fromSelect.options) toSelect.appendChild(opt.cloneNode(true));
  toSelect.selectedIndex=0;
}

async function onAutosChange(e){
  if(e.target.classList.contains('auto-marca')){
    const $row = e.target.closest('.auto-row');
    const $modelo = $row.querySelector('.auto-modelo');
    await fillModelos(e.target.value, $modelo);
  }
}

async function fillMarcas($selectMarca){
  const base = await findApiBase();
  $selectMarca.innerHTML = `<option value="" disabled selected>Marca</option>`;
  try{
    const res = await fetch(`${base}/modelos/marcas`);
    const data = await res.json();
    const unique = [...new Map((data.marcas||[])
      .map(m => [String(m).trim().toLowerCase(), String(m).trim().replace(/\s+/g,' ')]))
    ].map(([,pretty])=>pretty).sort((a,b)=>a.localeCompare(b,'es',{sensitivity:'base'}));
    unique.forEach(m=>{
      const opt=document.createElement('option');
      opt.value = opt.textContent = m;
      $selectMarca.appendChild(opt);
    });
  }catch(e){ console.error('Error cargando marcas',e); }
}

async function fillModelos(marca, $selectModelo){
  const st = modelosState.get($selectModelo) || { loading:false, marca:'' };
  if(st.loading) return;
  if(st.marca === marca) return;
  st.loading = true; modelosState.set($selectModelo, st);

  $selectModelo.innerHTML = `<option value="" disabled selected>Modelo</option>`;
  if(!marca){ $selectModelo.disabled=true; st.loading=false; return; }
  $selectModelo.disabled=false;

  const base = await findApiBase();
  try{
    const res = await fetch(`${base}/modelos?marca=${encodeURIComponent(marca)}`);
    const data = await res.json();
    const unique = [...new Map((data.modelos||[])
      .map(mo => [String(mo).trim().toLowerCase(), String(mo).trim().replace(/\s+/g,' ')]))
    ].map(([,pretty])=>pretty).sort((a,b)=>a.localeCompare(b,'es',{sensitivity:'base'}));
    unique.forEach(modelo=>{
      const opt=document.createElement('option');
      opt.value=opt.textContent=modelo;
      $selectModelo.appendChild(opt);
    });
    st.marca = marca;
  }catch(e){ console.error('Error cargando modelos',e); }
  finally{ st.loading=false; modelosState.set($selectModelo, st); }
}

// --- Pago al final ---
function initPlanBox(){
  const plan = document.querySelector('input[name="plan"]:checked')?.value || 'standard';
  $pagoSim.style.display = 'block';
  $pagoEstado.textContent = `Plan ${plan} — Importe AR$ ${PRICES[plan].toLocaleString('es-AR')}`;
}

document.addEventListener('change', (e)=>{
  if(e.target.name === 'plan'){
    resetPaymentUI();
    const plan = document.querySelector('input[name="plan"]:checked').value;
    $pagoSim.style.display = 'block';
    $pagoEstado.textContent = `Plan ${plan} — Importe AR$ ${PRICES[plan].toLocaleString('es-AR')}`;
  }
});

$btnProcesar?.addEventListener('click', ()=>{
  $pagoFlow.style.display = 'block';
  $pagoEstado.textContent = 'Seleccioná tu tarjeta para continuar.';
});

$brandGroup?.addEventListener('change', (e)=>{
  if(e.target.name === 'card_brand'){
    selectedBrand = e.target.value;
    enablePayIfReady();
  }
});

$cardLast4?.addEventListener('input', ()=>{
  $cardLast4.value = $cardLast4.value.replace(/\D/g,'').slice(0,4);
  enablePayIfReady();
});

$cardExp?.addEventListener('input', ()=>{
  let v = $cardExp.value.replace(/[^\d]/g,'').slice(0,4);
  if(v.length >= 3) v = v.slice(0,2) + '/' + v.slice(2);
  $cardExp.value = v;
  enablePayIfReady();
});

function enablePayIfReady(){
  const okLast4 = /^\d{4}$/.test($cardLast4.value);
  const okExp = /^((0[1-9])|(1[0-2]))\/\d{2}$/.test($cardExp.value);
  $btnPagar.disabled = !(selectedBrand && okLast4 && okExp);
}

$btnPagar?.addEventListener('click', async ()=>{
  if($btnPagar.disabled) return;
  $btnPagar.disabled = true;
  const prev = $btnPagar.textContent;
  $btnPagar.textContent = 'Procesando...';
  $pagoEstado.textContent = '';
  await new Promise(r => setTimeout(r, 900));
  paymentOk = true;
  $btnPagar.textContent = prev;
  const brandName = selectedBrand === 'visa' ? 'Visa' : 'Mastercard';
  $pagoEstado.textContent = `✔️ Pago aprobado con ${brandName}`;
});

function resetPaymentUI(){
  paymentOk = false;
  selectedBrand = null;
  $pagoFlow.style.display = 'none';
  $pagoEstado.textContent = '';
  $btnPagar.disabled = true;
  const sel = $brandGroup.querySelector('input[name="card_brand"]:checked');
  if(sel) sel.checked = false;
  $cardLast4.value = '';
  $cardExp.value = '';
}

// -------- PDF: Comprobante de pago/alta --------
function genOrderId(){
  const t = Date.now().toString(36);
  const r = Math.random().toString(36).slice(2,6);
  return `FS-${t}-${r}`.toUpperCase();
}
function formatDateTime(d=new Date()){
  const pad = n => String(n).padStart(2,'0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

async function generateReceiptPDF({ nombre, email, plan, amount, brand, last4, autosCount, orderId, ts }) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });

  const left = 48, right = 560;
  let y = 64;

  // Intentar cargar logo
  const logo = await loadImageAsDataURL('./assets/img/logo-fullservice.png');

  // Encabezado con barra azul
  doc.setFillColor(50, 91, 165); // azul
  doc.rect(0, 0, 595, 80, 'F'); // ancho total A4
  if (logo) {
    doc.addImage(logo, 'PNG', left, 18, 120, 40);
  }
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255);
  doc.setFontSize(18);
  doc.text('FullService - Comprobante de alta', logo ? left + 150 : left, 45);
  doc.setTextColor(0);

  y = 100;
  doc.setLineWidth(0.8);
  doc.line(left, y, right, y);
  y += 24;

  // Meta
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.text(`N° de comprobante: ${orderId}`, left, y); y += 16;
  doc.text(`Fecha y hora: ${ts}`, left, y); y += 24;

  // Usuario
  doc.setFont('helvetica', 'bold'); 
  doc.text('Datos del usuario', left, y); y += 14;
  doc.setFont('helvetica', 'normal');
  doc.text(`Nombre: ${nombre}`, left, y); y += 16;
  doc.text(`Email: ${email}`, left, y); y += 24;

  // Plan y pago
  doc.setFont('helvetica', 'bold'); 
  doc.text('Plan y pago', left, y); y += 14;
  doc.setFont('helvetica', 'normal');
  doc.text(`Plan contratado: ${plan === 'premium' ? 'Premium' : 'Standard'}`, left, y); y += 16;
  doc.text(`Importe: AR$ ${amount.toLocaleString('es-AR')}`, left, y); y += 16;
  doc.text(`Medio de pago: ${brand === 'visa' ? 'Visa' : 'Mastercard'} •••• ${last4}`, left, y); y += 24;

  // Vehículos
  doc.setFont('helvetica', 'bold'); 
  doc.text('Vehículos registrados', left, y); y += 14;
  doc.setFont('helvetica', 'normal');
  doc.text(`Cantidad: ${autosCount}`, left, y); y += 24;

  // Pie
  doc.setFont('helvetica', 'italic'); 
  doc.setTextColor(110);
  doc.text('Este es un comprobante no fiscal generado automáticamente por FullService.', left, y);
  doc.setTextColor(0);

  const filename = `comprobante-fullservice-${orderId}.pdf`;
  doc.save(filename);
}
