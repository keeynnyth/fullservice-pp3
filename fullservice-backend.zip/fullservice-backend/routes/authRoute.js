
// authRoute.js (Backend)
const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const con = require("../db");

// Ruta para login
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const [result] = await con.promise().query(
      "SELECT * FROM usuarios WHERE email = ?",
      [email]
    );

    if (result.length === 0) {
      return res.status(401).json({ mensaje: "Credenciales incorrectas" });
    }

    const usuario = result[0];

    // Comparar la contraseña cifrada con la contraseña proporcionada
    const match = await bcrypt.compare(password, usuario.password);
    if (!match) {
      return res.status(401).json({ mensaje: "Contraseña incorrecta" });
    }

    // Crear token con la información del usuario
    const token = jwt.sign(
      {
        id: usuario.id,
        nombre: usuario.nombre,
        email: usuario.email,
        rol: usuario.rol,
      },
      "secreto123",
      { expiresIn: "1h" }
    );

    // Enviar el token y el nombre del usuario en la respuesta
    res.status(200).json({
      mensaje: "Login exitoso",
      token,
      nombre: usuario.nombre,
    });
  } catch (err) {
    console.error("Error en login:", err);
    res.status(500).json({ mensaje: "Error interno del servidor" });
  }
});

module.exports = router;
