

// routes/perfil.js
const express = require('express');
const { pool } = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /perfil  -> datos del usuario + autos + cantidad de turnos del mes actual
router.get('/', requireAuth, async (req, res) => {
  try {
    const userId = req.user.id;

    const [usuarioRows] = await pool.query(
      `SELECT id, nombre, email, rol, terms_accepted_at, terms_version, marketing_opt_in, creado_en
         FROM usuarios
        WHERE id = ?
        LIMIT 1`,
      [userId]
    );
    if (!usuarioRows.length) {
      return res.status(404).json({ mensaje: 'Usuario no encontrado' });
    }
    const usuario = usuarioRows[0];

    const [autos] = await pool.query(
      `SELECT id, marca, modelo, anio
         FROM autos
        WHERE usuario_id = ?
        ORDER BY marca ASC, modelo ASC, anio DESC`,
      [userId]
    );

    const [turnosCountRows] = await pool.query(
      `SELECT COUNT(*) AS turnosCount
         FROM turnos
        WHERE usuario_id = ?
          AND MONTH(fecha) = MONTH(CURRENT_DATE())
          AND YEAR(fecha)  = YEAR(CURRENT_DATE())`,
      [userId]
    );
    const turnosCount = turnosCountRows[0]?.turnosCount || 0;

    res.json({
      usuario,
      autos,
      turnosCount,
      fechaRegistro: usuario.creado_en
    });
  } catch (error) {
    console.error('[GET /perfil] Error:', error);
    res.status(500).json({ mensaje: 'Error al obtener el perfil' });
  }
});

module.exports = router;
