
// routes/baja.js
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const con = require('../db');

// Middleware para verificar el token JWT
const verificarAuth = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(403).json({ mensaje: 'No autenticado' });

  try {
    const decoded = jwt.verify(token, 'secreto123');
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ mensaje: 'Token inválido' });
  }
};

// Ruta para solicitar la baja del usuario
router.post('/baja', verificarAuth, async (req, res) => {
  const userId = req.user.id;

  try {
    // Desactivar la cuenta del usuario
    await con.promise().query('UPDATE usuarios SET activo = 0 WHERE id = ?', [userId]);

    // También puedes eliminar todos los datos asociados si lo deseas
    // await con.promise().query('DELETE FROM autos WHERE usuario_id = ?', [userId]);
    // await con.promise().query('DELETE FROM turnos WHERE usuario_id = ?', [userId]);

    res.json({ mensaje: 'Tu cuenta ha sido dada de baja' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ mensaje: 'Error al procesar la baja' });
  }
});

module.exports = router;
