

// middleware/auth.js
const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  try {
    const header = req.headers['authorization'] || '';
    const parts = header.split(' ');
    const token = parts.length === 2 ? parts[1] : null;
    if (!token) return res.status(401).json({ mensaje: 'No autenticado' });

    const payload = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    req.user = { id: payload.sub, rol: payload.rol || 'usuario' };
    next();
  } catch (e) {
    return res.status(401).json({ mensaje: 'Token inválido o expirado' });
  }
}

module.exports = { requireAuth };
